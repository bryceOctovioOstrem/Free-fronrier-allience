Starsector Player Faction Flags and Crests
========================================

17 matched flag + crest pairs (34 PNG files).
Copy the included graphics/ directory into your Starsector mod folder.
Filenames match the player.faction flags block numbered 01 through 17.
Each crest is a circular PNG with transparency outside the medallion.

Number / Ideology or design:
  01  Anarcho Capitalism
  02  Minarchism
  03  Voluntaryism
  04  Agorism
  05  Classical Liberalism
  06  Objectivism
  07  Paleolibertarianism
  08  Geolibertarianism
  09  Laissez Faire Capitalism
  10  Libertarian Transhumanism
  11  Compass And Eagles
  12  White Eagle
  13  Winged Torch
  14  Porcupine
  15  Crossed Keys
  16  Golden Eagle
  17  Snake And Revolvers

Example player.faction entry:
  {"logo":"graphics/factions/custom/player_logo01_flag.png",
   "crest":"graphics/factions/custom/player_logo01_crest.png"}

NOTE: The vanilla player faction flag is not included: it is already in the base game.
